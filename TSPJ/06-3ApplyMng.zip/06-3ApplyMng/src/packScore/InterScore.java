package packScore;

interface InterScore {
	public static final int many = 3;
	boolean putScore(String txt);
	double getAvg();
	String getNo();
	String toString();
}
